abstract class Monster {
    String name;

    abstract String attack();
}

class FireMonster extends Monster {
    String attack() {
        return "FireMonster";
    }
}

class WaterMonster extends Monster {
    String attack() {
        return "WaterMonster";
    }
}

class StoneMonster extends Monster {
    String attack() {
        return "StoneMonster";
    }
}

class test {
    public static void main(String[] args) {
        Monster fm = new FireMonster();
        System.out.println("Type of Monster attack=" + fm.attack());
        Monster wm = new WaterMonster();
        System.out.println("Type of Monster attack=" + wm.attack());
        Monster sm = new StoneMonster();
        System.out.println("Type of Monster attack=" + sm.attack());
    }
}