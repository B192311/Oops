import java.util.*;
import java.lang.*;

public class E_CommerceApp {
    static void offerDecider(double total_bill, String customer_speciality) {
        double Amazon_price = 0;
        double Flipkart_price = 0;
        if (customer_speciality.equalsIgnoreCase("HDFC")) {
            Amazon_price -= ((0.10) * (total_bill));
        }
        if (total_bill > 50000) {
            Amazon_price -= ((0.15) * (total_bill));
        }
        if (customer_speciality.equalsIgnoreCase("RGUKT student")) {
            Flipkart_price -= ((0.30) * (total_bill));
        }
        if (total_bill > 30000) {
            Flipkart_price -= ((0.05) * (total_bill));
        }

        String Best_Ecom = (Amazon_price < Flipkart_price) ? "Amazon" : "Flipkart";
        System.out.println("Best E-commerce=" + Best_Ecom);
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String product_name, company;
        int quantity;
        double price, total_bill;
        System.out.println("enter product name,company to purchase=");
        product_name = s.nextLine();
        company = s.next();
        System.out.println("enter quantity of product=");
        quantity = s.nextInt();
        System.out.println("enter price of each product=");
        price = s.nextInt();
        total_bill = quantity * price;
        System.out.println("total_bill=" + total_bill);
        String customer_speciality;
        System.out.println("enter wheather customer consist HDFC credit card or RGUKT student=");
        customer_speciality = s.next();
        offerDecider(total_bill, customer_speciality);
    }
}
