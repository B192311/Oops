import java.util.Scanner;

abstract class Shape {
    abstract int getArea();

    abstract int getPerimeter();
}

class square extends Shape {
    double side;

    square(double side) {
        this.side = side;
    }

    int getArea() {
        return (int) (side * side);
    }

    int getPerimeter() {
        return (int) (4 * side);
    }
}

class circle extends Shape {
    double rad;

    circle(double rad) {
        this.rad = rad;
    }

    int getArea() {
        return (int) (3.14 * rad * rad);
    }

    int getPerimeter() {
        return (int) (2 * 3.14 * rad);
    }
}

class rectangle extends Shape {
    double l, w;

    rectangle(double l, double w) {
        this.l = l;
        this.w = w;
    }

    int getArea() {
        return (int) (l * w);
    }

    int getPerimeter() {
        return (int) (2 * (l + w));
    }

}

class test {
    public static void main(String[] args) {
        double side, length, width, radius;
        Scanner s = new Scanner(System.in);

        System.out.println("enter square side=");
        side = s.nextDouble();
        Shape sh1 = new square(side);
        System.out.println("Area of square=" + sh1.getArea() + ",perimeter of square=" + sh1.getPerimeter());

        System.out.println("enter rect length,width=");
        length = s.nextDouble();
        width = s.nextDouble();
        Shape sh2 = new rectangle(length, width);
        System.out.println("Area of rectangle=" + sh2.getArea() + ",perimeter of rectangle=" + sh2.getPerimeter());

        System.out.println("enter circle radius=");
        radius = s.nextDouble();
        Shape sh3 = new circle(radius);
        System.out.println("Area of circle=" + sh3.getArea() + ",perimeter of circle=" + sh3.getPerimeter());

    }
}