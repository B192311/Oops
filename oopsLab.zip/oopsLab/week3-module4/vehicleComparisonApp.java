import java.util.*;

class Vehicle {
    String company;
    String model;
    double mileage;
    double fuel_capacity;
    double displacement;

    Vehicle(String company, String model, double mileage, double fuel_capacity, double displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuel_capacity = fuel_capacity;
        this.displacement = displacement;
    }
}

class TwoWheeler extends Vehicle {
    String FrontBrake;
    String RearBrake;
    String TyreType;
    String Headlamp;
    String UserReviews;

    TwoWheeler(String FrontBrake, String RearBrake, String TyreType, String Headlamp, String UserReviews,
            String company, String model, double mileage, double fuel_capacity, double displacement) {
        super(company, model, mileage, fuel_capacity, displacement);
        this.FrontBrake = FrontBrake;
        this.RearBrake = RearBrake;
        this.TyreType = TyreType;
        this.Headlamp = Headlamp;
        this.UserReviews = UserReviews;
    }

    void display() {
        System.out.println("company=" + company + ",model=" + model + ",mileage=" + mileage + ",fuel_capacity="
                + fuel_capacity + "displacement=" + displacement);
        System.out.println("FrontBrake=" + FrontBrake + ",aRearBrake=" + RearBrake + ",TyreType=" + TyreType
                + ",Headlamp=" + Headlamp + ",UserReviews=" + UserReviews);
    }
}

class FourWheeler extends Vehicle {
    boolean AirConditioner;
    boolean airbags;
    boolean PowerSteering;
    boolean RainSensingWiper;

    FourWheeler(boolean AirConditioner, boolean airbags, boolean PowerSteering, boolean RainSensingWiper,
            String company, String model, double mileage, double fuel_capacity, double displacement) {
        super(company, model, mileage, fuel_capacity, displacement);
        this.AirConditioner = AirConditioner;
        this.PowerSteering = PowerSteering;
        this.RainSensingWiper = RainSensingWiper;
        this.airbags = airbags;
    }

    void display() {
        System.out.println("company=" + company + ",model=" + model + ",mileage=" + mileage + ",fuel_capacity="
                + fuel_capacity + "displacement=" + displacement);
        System.out.println("AirConditioner=" + AirConditioner + ",airbags=" + airbags + ",PowerSteering="
                + PowerSteering + ",RainSensingWiper=" + RainSensingWiper);
    }
}

class vehicleComparisonApp {
    public static void main(String[] args) {
        List<TwoWheeler> Tw = new ArrayList<>();
        List<FourWheeler> Fw = new ArrayList<>();
        TwoWheeler t1 = new TwoWheeler("fb1", "rb1", "tt1", "hl1", "Great", "Tcom1", "Tmod1", 2000, 3000, 45);
        TwoWheeler t2 = new TwoWheeler("fb2", "rb2", "tt2", "hl2", "Good", "Tcom2", "Tmod2", 700, 2000, 33);
        TwoWheeler t3 = new TwoWheeler("fb3", "rb3", "tt3", "hl3", "Awesome", "Tcom3", "Tmod3", 5000, 10000, 49);
        TwoWheeler t4 = new TwoWheeler("fb4", "rb4", "tt4", "hl4", "better", "Tcom4", "Tmod4", 800, 2000, 36);

        Tw.add(t1);
        Tw.add(t2);
        Tw.add(t3);
        Tw.add(t4);

        FourWheeler f1 = new FourWheeler(true, false, true, true, "Fcom1", "Fmod1", 2000, 3000, 45);
        FourWheeler f2 = new FourWheeler(false, true, true, true, "Fcom2", "Fmod2", 8000, 5000, 55);
        FourWheeler f3 = new FourWheeler(true, false, true, true, "Fcom3", "Fmod3", 500, 3000, 52);
        FourWheeler f4 = new FourWheeler(false, true, true, true, "Fcom4", "Fmod4", 6000, 2000, 43);

        Fw.add(f1);
        Fw.add(f2);
        Fw.add(f3);
        Fw.add(f4);

        Scanner sc = new Scanner(System.in);
        System.out
                .println("customer choice:\nEnter ->1 for TwoWheeler comparison\nEnter ->2 for FourWheeler comparison");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("Available TwoWheelers are:");
            for (TwoWheeler bike : Tw) {
                System.out.println(bike.company + " " + bike.model);
            }

            double maxTmileage = 0;
            double maxTFuelCapacity = 0;
            double maxTDisplacement = 0;
            TwoWheeler bike_obj = null;
            for (TwoWheeler bike : Tw) {
                if (bike.mileage > maxTmileage && bike.fuel_capacity > maxTFuelCapacity
                        && bike.displacement > maxTDisplacement) {
                    maxTDisplacement = bike.displacement;
                    maxTFuelCapacity = bike.fuel_capacity;
                    maxTmileage = bike.mileage;
                    bike_obj = bike;
                }
            }
            if (bike_obj != null) {
                System.out.print("Best available FourWheeler: ");
                bike_obj.display();
            } else {
                System.out.println("Best TwoWheeler with high resources is not available!");
            }

        } else if (choice == 2) {
            System.out.println("Available FourWheelers are:");
            for (FourWheeler car : Fw) {
                System.out.println(car.company + " " + car.model);
            }
            // checking for best car(fourwheeler)
            double maxFmileage = 0;
            double maxFFuelCapacity = 0;
            double maxFDisplacement = 0;
            FourWheeler car_obj = null;
            for (FourWheeler car : Fw) {
                if (car.mileage > maxFmileage && car.fuel_capacity > maxFFuelCapacity
                        && car.displacement > maxFDisplacement) {
                    maxFDisplacement = car.displacement;
                    maxFFuelCapacity = car.fuel_capacity;
                    maxFmileage = car.mileage;
                    car_obj = car;
                }
            }
            if (car_obj != null) {
                System.out.print("Best available FourWheeler: ");
                car_obj.display();
            } else {
                System.out.println("Best FourWheeler with high resources is not available!");
            }
        }

    }
}