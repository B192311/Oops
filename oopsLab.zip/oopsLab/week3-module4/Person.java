class Person {
    String name;
    String Address;

    Person() {

    }

    Person(String name, String Address) {
        this.name = name;
        this.Address = Address;
    }

    String getName() {
        return name;
    }

    String getAddress() {
        return Address;
    }
}

class Student extends Person {
    int num_courses = 0;
    String[] Courses = new String[30];
    int[] Grades = new int[30];

    Student() {

    }

    Student(String nam, String add) {
        this.name = nam;
        this.Address = add;
    }

    void addCourseGrade(String c, int g) {
        Courses[num_courses] = c;
        Grades[num_courses] = g;
        num_courses++;
    }

    void printGrades() {
        for (int i = 0; i < num_courses; i++) {
            System.out.print(Grades[i] + " ");
        }
    }

    void printCourses() {
        for (int i = 0; i < num_courses; i++) {
            System.out.print(Courses[i] + " ");
        }
    }

    double getAverageGrade() {
        double sum = 0;
        for (int i = 0; i < num_courses; i++) {
            sum = sum + Grades[i];
        }
        sum = sum / num_courses;
        return sum;
    }
}

class Teacher extends Person {
    int num_courses = 0;
    String[] courses = new String[5];

    Teacher() {

    }

    Teacher(String n, String a) {
        name = n;
        Address = a;
    }

    boolean addCourse(String c) {
        int flag = 1;
        for (int i = 0; i < num_courses; i++) {
            if (courses[i] == c) {
                flag = 0;
                // System.out.println("course already exist");
                break;
            }
        }
        if (flag == 0)
            return false;
        else {
            courses[num_courses] = c;
            num_courses++;
            return true;
        }
    }

    boolean removeCourse(String c) {
        int flag = 0;
        for (int i = 0; i < num_courses; i++) {
            if (courses[i] == c) {
                flag = 1;
                for (int j = i; j < num_courses - 1; j++) {
                    courses[i] = courses[i + 1];
                }
                num_courses--;
            }
        }
        if (flag == 1)
            return true;
        else
            return false;
    }
}

class test {
    public static void main(String[] args) {
        Student s1 = new Student("bhavani", "jagityal");
        Student s2 = new Student("rachana", "HYD");
        s1.addCourseGrade("DSA", 9);
        s1.addCourseGrade("OOPS", 8);
        s1.addCourseGrade("DAA", 7);
        s2.addCourseGrade("DM", 8);
        s2.addCourseGrade("Mefa", 9);
        s2.addCourseGrade("FLAT", 7);

        System.out.print(s1.name + " grades=");
        s1.printGrades();
        System.out.print(",courses=");
        s1.printCourses();
        System.out.println(" and avg_grades=" + s1.getAverageGrade());

        System.out.print(s2.name + " grades=");
        s2.printGrades();
        System.out.print(",courses=");
        s2.printCourses();
        System.out.println(" and avg_grades=" + s2.getAverageGrade());

        Teacher t1 = new Teacher("Ramanujan", "MUMBAI");
        Teacher t2 = new Teacher("srinivas", "Delhi");
        if (t1.addCourse("DAA") == false)
            System.out.println("course already exist.");
        if (t1.addCourse("C lang") == false)
            System.out.println("course already exist.");

        if (t2.addCourse("Graphics") == false)
            System.out.println("course already exist.");
        if (t2.addCourse("BEE") == false)
            System.out.println("course already exist.");

        if (t1.removeCourse("DAA") == true)
            System.out.println("DAA course removed successfully.");
        else
            System.out.println("DAA course not taught by teacher " + t1.name);

        if (t1.removeCourse("DAA") == true)
            System.out.println("DAA course removed successfully.");
        else
            System.out.println("DAA course not taught by teacher " + t1.name);

    }
}
