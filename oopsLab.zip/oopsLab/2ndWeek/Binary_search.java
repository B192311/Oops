import java.util.*;

public class Binary_search {
    public static boolean binary(int[] a, int ele, int l, int h) {

        while (l < h) {
            int mid = (l + h) / 2;
            if (a[mid] == ele)
                return true;
            else if (ele < a[mid]) {
                h = mid - 1;
            } else if (ele > a[mid]) {
                l = mid + 1;
            }
        }
        return false;
    }

    public static void sorting(int[] a, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (a[j] > a[j + 1]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter size=");
        int n = s.nextInt();
        int[] a = new int[n];
        System.out.println("enter elements=");
        for (int i = 0; i < n; i++) {
            a[i] = s.nextInt();
        }
        System.out.println("enter ele to search=");
        int ele = s.nextInt();
        sorting(a, n);
        boolean b = binary(a, ele, 0, n - 1);
        if (b == true)
            System.out.println("ele:" + ele + " is found");
        else
            System.out.println("ele:" + ele + " is not found");
    }

}
