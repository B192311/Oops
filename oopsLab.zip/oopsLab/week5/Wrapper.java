import java.util.*;

class Wrapper {
    public static void main(String[] args) {
        // valueOf(String s)-> takes string as i/p
        // ->return type= wrapper itself
        String s = "38";
        System.out.println("Integer value from string" + Integer.valueOf(s));
        System.out.println("double from string=" + Double.valueOf(s));
        // valueOf(String s,int radix)
        System.out.println("valueOf(String , radix)" + Integer.valueOf("1111", 2));
        // toString(),toString(primitive p)
        int k = 10;
        Integer i = 128;
        String f = Integer.toString(k);
        System.out.println("tostring(p)=" + f);
        System.out.println("toString()" + i.toString());// ->for non-primitive
        // xxxValue()
        System.out.println("i.intValue()=" + i.intValue());
        System.out.println("i.byteValue()=" + i.byteValue());
        // parseXXX(String s)->s must be numbers
        System.out.println("Integer.parseInt()=" + Integer.parseInt("123"));
        System.out.println("Double.parseDouble()=" + Double.parseDouble("34.66"));
    }
}