public class callBy {
    static int n = 45;

    static void callValue(int n) {
        n = 50;
        System.out.println("local value=" + n);
    }

    static void callReference(callBy b) {
        b.n = 34;
        System.out.println("local value by ref=" + n);
    }

    public static void main(String[] args) {
        System.out.println("initial value=" + n);
        callValue(n);
        System.out.println("final value=" + n);
        callBy b = new callBy();
        callReference(b);// passing obj
        System.out.println("reference final value=" + n);
    }
}
