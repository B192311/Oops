package p1;

public class mypack2 {
    public void show() {
        System.out.println("inside mypack2");
    }
}
// num of classes = no.of files and import required package,
// package samepackage -> if two or more classes inside same class must exist