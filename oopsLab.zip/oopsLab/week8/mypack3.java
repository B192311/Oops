package p1;

public class mypack3 {
    public void show() {
        System.out.println("inside mypack3");
    }
}
