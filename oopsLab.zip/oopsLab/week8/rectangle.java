package org.shapes;

public class rectangle {
    public void area(int l, int b) {
        System.out.println("area of rectangle=" + l * b);
    }
}
