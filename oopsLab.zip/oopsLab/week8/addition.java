package calculator;

public class addition {
    public void add(int x, int y) {
        System.out.println(x + y);
    }
}
