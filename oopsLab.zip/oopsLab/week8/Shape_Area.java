package shape;

import org.shapes.*;

public class Shape_Area {
    public static void main(String[] args) {
        circle c = new circle();
        c.area(4);
        cube cu = new cube();
        cu.area(5);
        cuboid cub = new cuboid();
        cub.area(2, 3, 4);
        triangle t = new triangle();
        t.Area(3, 5);
        square s = new square();
        s.Area(3);
        rectangle r = new rectangle();
        r.area(3, 4);
    }
}
