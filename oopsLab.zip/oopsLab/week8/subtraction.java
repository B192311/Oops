package calculator;

public class subtraction {
    public void sub(int x, int y) {
        System.out.println(x - y);
    }
}
