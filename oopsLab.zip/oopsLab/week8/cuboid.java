package org.shapes;

public class cuboid {
    public void area(int l, int b, int h) {
        // 2(lb+bh+hl)
        System.out.println("area of cuboid=" + 2 * ((l * b) + (b * h) + (h * l)));
    }
}
