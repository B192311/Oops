import java.util.Scanner;

class Palindrome_num {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter num=");
        int n = s.nextInt();
        int temp = n, r = 0, sum = 0;
        while (n > 0) {
            r = n % 10;
            sum = sum * 10 + r;
            n = n / 10;
        }
        if (sum == temp)
            System.out.println(temp + " is palindrome");
        else
            System.out.println(temp + " is not palindrome");
    }
}