import java.util.Scanner;

class Calculator_op {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter operands=");
        double a = s.nextDouble();
        double b = s.nextDouble();
        System.out.println("enter an operation among->+,-,*,/,%");
        // s.next()->gives string, s.next().charAt(0)->allows char
        char ch = s.next().charAt(0);
        double c = 0;
        switch (ch) {
            case '+':
                c = a + b;
                System.out.println(a + "+" + b + "=" + c);
                break;
            case '-':
                c = a - b;
                System.out.println(a + "-" + b + "=" + c);
                break;
            case '*':
                c = a * b;
                System.out.println(a + "*" + b + "=" + c);
                break;
            case '/':
                c = a / b;
                System.out.println(a + "/" + b + "=" + c);
                break;
            case '%':
                c = a % b;
                System.out.println(a + "%" + b + "=" + c);
                break;
            default:
                System.out.println("invalid choice");
        }
    }
}