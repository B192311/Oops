abstract class shape {
    abstract double getArea();

    abstract double getPerimeter();
}

class circle extends shape {
    double r;

    circle(double r) {
        this.r = r;
    }

    String getShape() {
        return "circle";
    }

    double getArea() {
        return r * 3.14 * r;
    }

    double getPerimeter() {
        return 2 * 3.14 * r;
    }
}

class square extends shape {
    double r;

    square(double r) {
        this.r = r;
    }

    String getShape() {
        return "square";
    }

    double getArea() {
        return r * r;
    }

    double getPerimeter() {
        return 4 * r;
    }
}

class rect extends shape {
    double l, b, h;

    rect(double l, double b, double h) {
        this.l = l;
        this.b = b;
        this.h = h;
    }

    String getShape() {
        return "rectangle";
    }

    double getArea() {
        return l * b * h;
    }

    double getPerimeter() {
        return 2 * (l + b);
    }
}

class cube extends shape {
    double s;

    cube(double s) {
        this.s = s;
    }

    String getShape() {
        return "cube";
    }

    double getArea() {
        return 6 * s * s;
    }

    double getPerimeter() {
        return 12 * s;
    }
}

class sphere extends shape {
    double r;

    sphere(double r) {
        this.r = r;
    }

    String getShape() {
        return "sphere";
    }

    double getArea() {
        return 4 * 3.14 * r * r;
    }

    double getPerimeter() {
        return (4 / 3) * 3.14 * r * r * r;
    }
}

class test {
    public static void main(String[] args) {
        circle c = new circle(3);
        System.out.println("area of " + c.getShape() + "=" + c.getArea());
        System.out.println("perimeter of " + c.getShape() + "=" + c.getPerimeter());
        // do same for every shape
    }
}