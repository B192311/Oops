import java.util.*;

class Area {
    int l, b;

    void setDim(int l, int b) {
        this.l = l;
        this.b = b;
    }

    int getArea() {
        return (l * b);
    }
}

class RectangleArea {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter length,breadth=");
        int l = s.nextInt();
        int b = s.nextInt();
        Area a = new Area();
        a.setDim(l, b);
        System.out.println("Area of rectangle=" + a.getArea());
    }
}