import java.util.*;

public class Complex {

    static void sum(double real1, double imag1, double real2, double imag2) {
        double realpart = real1 + real2;
        double imagpart = imag1 + imag2;
        if (imagpart < 0)
            System.out.println("sum=" + (int) realpart + "-i" + (int) (-imagpart));
        else
            System.out.println("sum=" + (int) realpart + "+i" + (int) (imagpart));
    }

    static void diff(double real1, double imag1, double real2, double imag2) {
        double realpart = real1 - real2;
        double imagpart = imag1 - imag2;
        if (imagpart < 0)
            System.out.println("diff=" + (int) realpart + "-i" + (int) (-imagpart));
        else
            System.out.println("diff=" + (int) realpart + "+i" + (int) (imagpart));
    }

    static void mul(double real1, double imag1, double real2, double imag2) {
        double realpart = (real1 * real2) - (imag1 * imag2);// (ac-bd)+i(ad+bc)
        double imagpart = (real1 * imag2) + (imag1 * real2);
        if (imagpart < 0)
            System.out.println("mul=" + (int) realpart + "-i" + (int) (-imagpart));
        else
            System.out.println("mul=" + (int) realpart + "+i" + (int) imagpart);
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter complex_num1 parts=");
        double real1 = s.nextDouble();
        double imag1 = s.nextDouble();
        System.out.println("enter complex_num2 parts=");
        double real2 = s.nextDouble();
        double imag2 = s.nextDouble();
        sum(real1, imag1, real2, imag2);
        diff(real1, imag1, real2, imag2);
        mul(real1, imag1, real2, imag2);
    }
}
