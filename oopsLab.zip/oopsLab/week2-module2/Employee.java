public class Employee {
    public static void main(String[] args) {
        System.out.println("Name    Year of joining Address");
        System.out.println("Robert  1994    64C-WallsStreet");
        System.out.println("Sam     2000    68D-WallsStreet");
        System.out.println("John    1999    26B-WallsStreet");
    }
}
