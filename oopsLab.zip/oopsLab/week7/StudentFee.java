interface StudentFee {
    double getAmount();

    String getFirstName();

    String getLastName();

    String getAddress();

    String getContact();
}

class hosteler implements StudentFee {
    String Fname, Lname, address;
    double Amount;
    String contact;

    hosteler(String Fname, String Lname, String address, double Amount, String contact) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.address = address;
        this.Amount = Amount;
        this.contact = contact;
    }

    public double getAmount() {
        return Amount;
    }

    public String getContact() {
        return contact;
    }

    public String getFirstName() {
        return Fname;
    }

    public String getLastName() {
        return Lname;
    }

    public String getAddress() {
        return address;
    }

}

class nonHosteler implements StudentFee {
    String Fname, Lname, address;
    double Amount;
    String contact;

    nonHosteler(String Fname, String Lname, String address, double Amount, String contact) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.address = address;
        this.Amount = Amount;
        this.contact = contact;
    }

    public double getAmount() {
        return Amount;
    }

    public String getContact() {
        return contact;
    }

    public String getFirstName() {
        return Fname;
    }

    public String getLastName() {
        return Lname;
    }

    public String getAddress() {
        return address;
    }
}

class test {
    public static void main(String[] args) {
        hosteler h = new hosteler("dasari", "bhavani", "ibp", 50000, "9721364342");
        System.out.println(h.getFirstName());
        System.out.println(h.getLastName());
        System.out.println(h.getAddress());
        System.out.println(h.getAmount());
        System.out.println(h.getContact());
        nonHosteler nh = new nonHosteler("duddula", "rachana", "ibp", 70000, "8841367342");
        System.out.println(nh.getFirstName());
        System.out.println(nh.getLastName());
        System.out.println(nh.getAddress());
        System.out.println(nh.getAmount());
        System.out.println(nh.getContact());
    }
}