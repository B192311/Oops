import java.util.*;

interface payable {
    double getAmount();
}

public class Inteterface_example implements payable {
    double amt;

    public double getAmount() {
        return amt;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Inteterface_example i = new Inteterface_example();
        System.out.println("enter amount to pay for invoice=");
        i.amt = s.nextDouble();
        System.out.println(i.getAmount());
    }
}
