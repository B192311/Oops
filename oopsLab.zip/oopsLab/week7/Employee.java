public abstract class Employee {
    String name, dept;

    Employee(String name, String dept) {
        this.name = name;
        this.dept = dept;
    }

    abstract double getSalary();
}

class test {
    public static void main(String[] args) {
        HourlyEmp eh = new HourlyEmp("bhavani", "cse");
        eh.wagePerHour = 3000;
        eh.numofHours = 42;
        System.out.println("salary of dept " + eh.getDept() + " deisgnation=" + eh.getDesig() + "=" + eh.getSalary());
        WeeklyEmp ew = new WeeklyEmp("john", "IT");
        ew.wagePerWeek = 20000;
        ew.numofWeeks = 3;
        System.out.println("salary of dept " + eh.getDept() + " deisgnation=" + ew.getDesig() + "=" + ew.getSalary());
    }
}

class HourlyEmp extends Employee {
    int numofHours;
    double wagePerHour;

    HourlyEmp(String name, String dept) {
        super(name, dept);
    }

    String getDept() {
        return super.dept;
    }

    String getDesig() {
        return "Hourly Emp";
    }

    double getSalary() {
        return wagePerHour * numofHours;
    }
}

class WeeklyEmp extends Employee {
    int numofWeeks;
    double wagePerWeek;

    String getDesig() {
        return "Weekly Emp";
    }

    String getDept() {
        return super.dept;
    }

    WeeklyEmp(String name, String dept) {
        super(name, dept);
    }

    double getSalary() {
        return numofWeeks * wagePerWeek;
    }
}
