import java.lang.*;
import java.util.*;
class string7{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter string=");
		String s1=s.nextLine();
		System.out.println("substring="+s1.substring(3,6));
		System.out.println("startWith="+s1.startsWith("k"));
		System.out.println("endsWith="+s1.endsWith("a"));
	}
}