import java.lang.*;
import java.util.*;
class string6{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter string=");
		String s1=s.nextLine();
		String sb="";
		int i=0,j=s1.length()-1;
		while(j>=0)
		{
		  sb += s1.charAt(j);
                  j--;
		}
		System.out.println(sb);
	}
}
		
		