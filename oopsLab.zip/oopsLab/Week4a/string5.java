import java.lang.*;
import java.util.*;
class string5{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter string=");
		String s1=s.nextLine();
		int c=0;
		for(char ch: s1.toCharArray())
		{
			c++;
		}
		System.out.println("string length="+c);
	}
}