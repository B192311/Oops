import java.util.*;

class product {
    int pid, pquant;
    String pname;
    double pprice;

    product(int pid, String pname, double pprice) {
        this.pid = pid;
        this.pname = pname;
        this.pprice = pprice;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        product[] p = new product[5];
        p[0] = new product(1, "product-1", 99.90);
        p[1] = new product(2, "product-2", 20.20);
        p[2] = new product(3, "product-3", 6.87);
        p[3] = new product(4, "product-4", 45.50);
        p[4] = new product(5, "product-5", 40.49);
        int quantity = 0;
        String exitResponse = "no";
        int pid;
        double total_bill = 0;
        while (true) {
            System.out.println("enter pid of buying product=");
            pid = s.nextInt();
            switch (pid) {
                case 1:
                    System.out.println("enter quantity of product " + p[0].pid);
                    quantity = s.nextInt();
                    p[0].pquant = quantity;
                    total_bill += (p[0].pprice * p[0].pquant);
                    break;
                case 2:
                    System.out.println("enter quantity of product " + p[1].pid);
                    quantity = s.nextInt();
                    p[1].pquant = quantity;
                    total_bill += (p[1].pprice * p[1].pquant);
                    break;
                case 3:
                    System.out.println("enter quantity of product " + p[2].pid);
                    quantity = s.nextInt();
                    p[2].pquant = quantity;
                    total_bill += (p[2].pprice * p[2].pquant);
                    break;
                case 4:
                    System.out.println("enter quantity of product " + p[3].pid);
                    quantity = s.nextInt();
                    p[3].pquant = quantity;
                    total_bill += (p[3].pprice * p[3].pquant);
                    break;
                case 5:
                    System.out.println("enter quantity of product " + p[4].pid);
                    quantity = s.nextInt();
                    p[4].pquant = quantity;
                    total_bill += (p[4].pprice * p[4].pquant);
                    break;
                default:
                    System.out.println("enter correct pid!!");
            }
            System.out.println("enter exitResponse yes/no=");
            exitResponse = s.next();
            if (exitResponse.equals("yes"))
                break;
        }
        System.out.println("entire bill for all products bought=" + total_bill);
    }
}